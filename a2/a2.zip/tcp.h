#include <stdio.h>
#include <stdlib.h>
#include "list.h"


static void* keyboard();
static void* display();
static void* receive();
static void* sendMessage();

